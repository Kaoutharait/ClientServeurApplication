package ClientServeurApplication;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Clients {

	public static void main(String[] args) {
		 try (Socket socket = new Socket("localhost", 2525);
	             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
	             Scanner scanner = new Scanner(System.in)) {

	            // Lire le message de bienvenue du serveur
	            System.out.println("Serveur: " + reader.readLine());

	            // Envoyer des messages au serveur
	            String message;
	            while (true) {
	                System.out.print("Votre message (ou 'quit' pour quitter): ");
	                message = scanner.nextLine();

	                writer.write(message + "\n");
	                writer.flush();

	                if ("quit".equalsIgnoreCase(message)) {
	                    break;
	                }

	                // Lire la réponse du serveur
	                System.out.println("Serveur: " + reader.readLine());
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}