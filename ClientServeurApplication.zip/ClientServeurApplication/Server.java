package ClientServeurApplication;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;

public class Server {

	public static void main(String[] args) {
		        ServerSocket serverSocket;

		        try {
		            // Choisir un port et s'assurer que le serveur écoute correctement
		            serverSocket = new ServerSocket();
		            serverSocket.setReuseAddress(true); // Permet de réutiliser le port immédiatement après fermeture
		            serverSocket.bind(new InetSocketAddress(2525)); // Bind au port 2525

		            System.out.println("Serveur concurrent prêt sur le port 2525.");

		            // Lancer le thread pour accepter des connexions clients
		            Thread acceptThread = new Thread(new AccepterClients(serverSocket));
		            acceptThread.start();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		    }
		}

		class AccepterClients implements Runnable {
		    private ServerSocket serverSocket;
		    private int nbrClient = 1; // Compteur de clients

		    public AccepterClients(ServerSocket serverSocket) {
		        this.serverSocket = serverSocket;
		    }

		    @Override
		    public void run() {
		        try {
		            while (true) {
		                // Accepter une connexion client
		                Socket clientSocket = serverSocket.accept();
		                System.out.println("Le client numéro " + nbrClient + " est connecté !");

		                // Créer un thread pour chaque client
		                Thread clientThread = new Thread(new ClientHandler(clientSocket, nbrClient));
		                clientThread.start();

		                nbrClient++;
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		    }
		}

		class ClientHandler implements Runnable {
		    private Socket clientSocket;
		    private int clientNumber;

		    public ClientHandler(Socket clientSocket, int clientNumber) {
		        this.clientSocket = clientSocket;
		        this.clientNumber = clientNumber;
		    }

		    @Override
		    public void run() {
		        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
		             BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

		            // Envoyer un message de bienvenue au client
		            writer.write("Bienvenue, Client numéro " + clientNumber + "!\n");
		            writer.flush();

		            // Gérer les messages du client
		            String message;
		            while ((message = reader.readLine()) != null) {
		                System.out.println("Message du Client " + clientNumber + ": " + message);

		                // Répondre au client (echo)
		                writer.write("Echo: " + message + "\n");
		                writer.flush();

		                if ("quit".equalsIgnoreCase(message)) {
		                    System.out.println("Le client numéro " + clientNumber + " s'est déconnecté.");
		                    break;
		                }
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        } finally {
		            try {
		                clientSocket.close();
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
		    }
		}
